// src/components/AssistantSection.tsx
import React, { useEffect, useRef, useState } from "react";

type Message = {
  role: "user" | "assistant";
  content: string;
};

const SYSTEM_PROMPT =
  "You are an AI assistant for Sarkis, an AI expert & full-stack developer. " +
  "Help visitors understand his services (bots, web apps, AI agents, generators) " +
  "and suggest how he can solve their tasks. Answer briefly, clearly and friendly. " +
  "If the user writes in Russian, answer in Russian. If in English, answer in English.";

const API_URL = "https://openrouter.ai/api/v1/chat/completions";

// модель берём из .env, чтобы можно было легко менять
const MODEL_ID =
  (import.meta.env.VITE_OPENROUTER_MODEL as string | undefined) ||
  "x-ai/grok-1-fast:free"; // запасной дефолт

export default function AssistantSection() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content:
        "Привет! Я AI-ассистент Саркиса. Опиши свою задачу — подскажу, какой бот, агент или сервис под неё подойдёт.",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const apiKey = import.meta.env.VITE_OPENROUTER_API_KEY as
    | string
    | undefined;

  // 🔥 Контейнер с сообщениями — будем крутить только его, а не страницу
  const messagesContainerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const el = messagesContainerRef.current;
    if (el) {
      el.scrollTop = el.scrollHeight;
    }
  }, [messages, loading]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    if (!apiKey) {
      setError(
        "AI ещё не настроен: отсутствует VITE_OPENROUTER_API_KEY. Добавь ключ в .env и перезапусти npm run dev."
      );
      return;
    }

    const modelId = MODEL_ID || import.meta.env.VITE_OPENROUTER_MODEL;
    if (!modelId) {
      setError(
        "Не указана модель: добавь VITE_OPENROUTER_MODEL в .env с реальным ID модели из OpenRouter."
      );
      return;
    }

    const userMessage: Message = { role: "user", content: input.trim() };
    const newMessages = [...messages, userMessage];

    setMessages(newMessages);
    setInput("");
    setLoading(true);
    setError(null);

    try {
      const res = await fetch(API_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
          "HTTP-Referer": "https://apint817-netizen.github.io/sarkis-landing/",
          "X-Title": "Sarkis AI Landing Assistant",
        },
        body: JSON.stringify({
          model: modelId,
          messages: [
            { role: "system", content: SYSTEM_PROMPT },
            ...newMessages.map((m) => ({
              role: m.role,
              content: m.content,
            })),
          ],
        }),
      });

      if (!res.ok) {
        let detail = "";
        try {
          const text = await res.text();
          detail = text.slice(0, 200);
        } catch {
          // ignore
        }
        throw new Error(`API error ${res.status}. ${detail}`);
      }

      const data = await res.json();
      const reply: string =
        data.choices?.[0]?.message?.content ?? "Модель не вернула ответа.";

      setMessages((prev) => [...prev, { role: "assistant", content: reply }]);
    } catch (e: any) {
      console.error(e);
      setError(
        "Не удалось получить ответ от AI. Попробуй ещё раз позже.\n" +
          (e?.message ? `Тех. деталь: ${e.message}` : "")
      );
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown: React.KeyboardEventHandler<HTMLInputElement> = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const renderMessage = (m: Message, idx: number) => {
    const isUser = m.role === "user";

    return (
      <div
        key={idx}
        className={`flex w-full gap-2 ${
          isUser ? "justify-end" : "justify-start"
        }`}
      >
        {/* Аватар ассистента слева */}
        {!isUser && (
          <div className="mt-1 flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-accent to-accent2 text-[11px] font-semibold">
            SA
          </div>
        )}

        <div
          className={`max-w-[80%] rounded-2xl px-3 py-2 text-sm leading-relaxed shadow-soft whitespace-pre-wrap ${
            isUser
              ? "bg-accent text-white font-semibold rounded-br-sm"
              : "bg-white/5 text-white/90 border border-white/10 font-medium rounded-bl-sm"
          }`}
        >
          {m.content}
        </div>

        {/* Аватар пользователя справа */}
        {isUser && (
          <div className="mt-1 flex h-7 w-7 items-center justify-center rounded-full bg-white/10 text-[11px] font-semibold text-white">
            Ты
          </div>
        )}
      </div>
    );
  };

  return (
    <section id="assistant" className="section-container pt-8 md:pt-16">
      <div className="flex flex-col md:flex-row md:items-start gap-8">
        {/* Левая колонка — описание */}
        <div className="md:w-1/3 space-y-3">
          <h2 className="section-title">AI-ассистент на сайте</h2>
          <p className="text-sm md:text-base text-white/70">
            Здесь можно вживую поговорить с AI-ассистентом Саркиса: описать
            задачу и получить идею решения — бот, агент, сервис или генератор.
          </p>

          <ul className="text-xs md:text-sm text-white/60 space-y-1">
            <li>• Помогает выбрать формат решения под твой бизнес.</li>
            <li>• Подсказывает, как внедрить AI в текущие процессы.</li>
            <li>• Понимает русский и английский, держит контекст про твои услуги.</li>
          </ul>

          <p className="text-[11px] text-white/40 pt-2">
            Текущая модель:{" "}
            <span className="font-mono break-all">
              {import.meta.env.VITE_OPENROUTER_MODEL || MODEL_ID}
            </span>
          </p>
        </div>

        {/* Правая колонка — чат */}
        <div className="md:w-2/3">
          <div className="rounded-2xl border border-white/10 bg-darkSoft/80 backdrop-blur-md shadow-soft flex flex-col h-[420px]">
            {/* Сообщения */}
            <div
              ref={messagesContainerRef}
              className="flex-1 overflow-y-auto px-4 py-3 space-y-3"
            >
              {messages.map(renderMessage)}
              {loading && (
                <div className="text-xs text-white/60 italic">
                  Ассистент думает…
                </div>
              )}
              {error && (
                <div className="text-xs text-red-400 whitespace-pre-wrap">
                  {error}
                </div>
              )}
            </div>

            {/* Поле ввода */}
            <div className="border-t border-white/10 px-3 py-2 flex items-center gap-2">
              <input
                type="text"
                placeholder="Опиши задачу или задай вопрос..."
                className="flex-1 bg-transparent outline-none text-sm text-white placeholder:text-white/40"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
              />
              <button
                onClick={handleSend}
                disabled={loading || !input.trim()}
                className="btn-primary text-xs px-3 py-1.5 disabled:opacity-60 disabled:cursor-not-allowed"
              >
                {loading ? "Отправка..." : "Отправить"}
              </button>
            </div>
          </div>
          <p className="mt-2 text-[11px] text-white/40">
            ⚠ Ассистент использует API OpenRouter. Убедись, что в .env заданы
            VITE_OPENROUTER_API_KEY и VITE_OPENROUTER_MODEL.
          </p>
        </div>
      </div>
    </section>
  );
}
